package com.jfs.backend.service;

import java.util.Arrays;
import java.util.Enumeration;
import java.util.Random;
import java.util.Scanner;
import java.util.Stack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jfs.backend.entity.Account;
import com.jfs.backend.repository.AccountRepository;

@Component
public class CreateNewAccount {

	@Autowired
	private AccountRepository accRep;
	
	Scanner sc = new Scanner(System.in);

	public void createNewAcc() {

		Random rnd = new Random();
		String accNum1 = "";
		String accNum = "";
		Stack st = new Stack();
		int k = 0;
		for (int i = 0; i < 5; i++) {

			st.add(k = rnd.nextInt(10));

		}
		Enumeration e = st.elements();

		while (e.hasMoreElements()) {
			accNum1 = String.valueOf(e.nextElement());
			// System.out.print(accNum1);
			accNum = accNum.concat(accNum1);
		}

//		System.out.print("Enter Your SrNo :");
//		int srNo = sc.nextInt();

		System.out.print("Enter Deposit AccBalance :");
		String accBalance = sc.nextLine();
		
		System.out.print("Enter Your Email Id :");
		String userEmail = sc.nextLine();
		
		System.out.print("Enter Your Gender :");
		String Gender = sc.nextLine();
		
		System.out.print("Enter Your userMobile :");
		String userMobile = sc.nextLine();
		
		System.out.print("Enter Your holderName :");
		String holderName = sc.nextLine();

		System.out.print("Enter Your UserName :");
		String username = sc.nextLine();

		System.out.print("Enter Your Password :");
		String password = sc.nextLine();
		
		Account ac=new Account(null, holderName, Gender, null, username, password, userEmail, holderName, userMobile);	
		accRep.save(ac);
	}
}
