package jfs.backend.bms.user.service.entity;

import lombok.Data;

@Data
public class login {

	private String userName;
	private String password;
	
	
}
