package jfs.backend.service;

import java.util.List;

import jfs.backend.payloads.CommentDto;

public interface CommentService {

	CommentDto createComment(CommentDto commentDto,Integer postId);
	
	String deleteComment(Integer commentId);
	
	List<CommentDto> getAllComments();
	
	
}
