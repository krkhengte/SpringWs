
package jfs.backend.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.PostRemove;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jfs.backend.entity.Comment;
import jfs.backend.entity.Post;
import jfs.backend.exceptions.ResourceNotFoundException;
import jfs.backend.payloads.CommentDto;
import jfs.backend.repository.CommentRepo;
import jfs.backend.repository.PostRepo;
import jfs.backend.service.CommentService;

@Service
public class CommentServiceImpl implements CommentService {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PostRepo postRepo;

	@Autowired
	private CommentRepo commentRepo;

	@Override
	public CommentDto createComment(CommentDto commentDto, Integer postId) {

		Post post = this.postRepo.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post", "postId", postId));

		Comment comment = this.modelMapper.map(commentDto, Comment.class);

		comment.setPost(post);

		Comment saveComment = this.commentRepo.save(comment);

		return this.modelMapper.map(saveComment, CommentDto.class);

	}

	@Override
	public String deleteComment(Integer commentId) {

		Comment comment = commentRepo.findById(commentId)
				.orElseThrow(() -> new ResourceNotFoundException("Comment", "commentId", commentId));
		this.commentRepo.delete(comment);
		
		return "Comment Deleted";
	}

	@Override
	public List<CommentDto> getAllComments() {
		
		List<Comment> comment = this.commentRepo.findAll();
		
		List<CommentDto> commentList=comment.stream().map((comm)->this.modelMapper.map(comm, CommentDto.class)).collect(Collectors.toList());
		
		return commentList;
	}

}
