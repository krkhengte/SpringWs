package jfs.backend.payloads;

import java.util.List;

import javax.jws.soap.SOAPBinding.Use;

import jfs.backend.entity.Post;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class CommentDto {

	private Integer id;
	private String content;
	
	/*
	 * private List<Use> userDto;
	 * 
	 * private List<Post> postDto;
	 */
}
