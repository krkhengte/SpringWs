package jfs.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import jfs.backend.entity.Comment;

public interface CommentRepo extends JpaRepository<Comment, Integer> {

}
