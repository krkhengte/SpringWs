package jfs.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import jfs.backend.entity.User;

public interface UserRepo extends JpaRepository<User, Integer>{

}
