package jfs.backend.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jfs.backend.dto.AddressDto;
import jfs.backend.dto.CustomerDto;
import jfs.backend.entity.Address;
import jfs.backend.entity.Customer;
import jfs.backend.entity.Mobile;
import jfs.backend.repository.AddressRepository;
import jfs.backend.repository.CustomerRepository;

@Service
public class CustomerService implements CustomerFunctions {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public String addCustomer(CustomerDto customersdto) {

		Integer id = customersdto.getId();
		
		  AddressDto addressDto = new AddressDto();
		  
		  Customer customers = this.DtoToCustomer(customersdto);
		  
		  List<Address> addresses = customers.getAddresses();
		  
		  if (addresses != null) { for (Address address : addresses) {
		  address.setCustomers(customers); } }
		  
		  
		  List<Mobile> mobiles = customers.getMobiles();
		  
		  if(mobiles != null) { for(Mobile mobile : mobiles) {
		  mobile.setCustomers(customers); } }
		 
		

		  //Customer save = this.customerRepository.save(customers);
		  customerRepository.save(customers);

		if (id != null) {
			return "Customer Added Successfully";
		} else {

			return "Failed To Add Customer";
		}

	}

	public Customer DtoToCustomer(CustomerDto customerDto) {

		return this.modelMapper.map(customerDto, Customer.class);
	}

	
	

}
