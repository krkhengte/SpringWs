
package jfs.backend.service;

import jfs.backend.dto.MobileDto;

public interface MobileFunction {

	public String addMobileNum(MobileDto mobileDto, Integer customerId);
}
