package jfs.backend.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jfs.backend.dto.AddressDto;
import jfs.backend.dto.CustomerDto;
import jfs.backend.entity.Customer;
import jfs.backend.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@PostMapping("/addCustomer")
	public ResponseEntity<String> addCustomerInfo(@RequestBody CustomerDto customersdto) {
		// String status="Customer Added Successfully";
		String addCust = customerService.addCustomer(customersdto);
		return new ResponseEntity<String>(addCust, HttpStatus.CREATED);

	}



}
