package jfs.backend.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jfs.backend.entity.Category;
import jfs.backend.entity.Product;
import jfs.backend.repository.CategoryRepository;
import jfs.backend.repository.ProductRepository;

@Service
public class CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	public void categoryData() {

		System.out.println("1");

		Product p1 = new Product();
		p1.setProductId(1);
		p1.setProductName("IPhone 14 Pro Max");
	//	p1.setCategories(null);

		Product p2 = new Product();
		p2.setProductId(2);
		p2.setProductName("Vivo T1 5G");

		Product p3 = new Product();
		p3.setProductId(3);
		p3.setProductName("SamSung S23 Ultra Pro");

		Category c1 = new Category();
		c1.setCId(10);
		c1.setTitle("Electronic");

		Category c2 = new Category();
		c2.setCId(11);
		c2.setTitle("Smart Phone");

		
		List<Product> c1Product = c1.getProducts();
		c1Product.add(p1);
		c1Product.add(p2);
		c1Product.add(p3);
		
		List<Product> c2Product = c2.getProducts();
		c2Product.add(p1);
		c2Product.add(p2);

		
		categoryRepository.save(c1);
		categoryRepository.save(c2);

		System.out.println("2");

	}

}
